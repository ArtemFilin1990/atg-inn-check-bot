import os
import re
import time
import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import requests
from fastapi import FastAPI, Request, Response, HTTPException

import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton


# -----------------------------
# Config
# -----------------------------
def _env(name: str, default: Optional[str] = None) -> str:
    v = os.getenv(name, default)
    return "" if v is None else str(v).strip()


TELEGRAM_BOT_TOKEN = _env("TELEGRAM_BOT_TOKEN")
DADATA_TOKEN = _env("DADATA_TOKEN")
DADATA_SECRET = _env("DADATA_SECRET", "")  # optional for profile methods, not required for party
WEBHOOK_PATH_SECRET = _env("TELEGRAM_WEBHOOK_PATH_SECRET", "secret-path")
WEBHOOK_SECRET_TOKEN = _env("TELEGRAM_WEBHOOK_SECRET_TOKEN", "")  # optional, checked in header
CACHE_TTL_SEC = int(_env("CACHE_TTL_SEC", "900"))  # 15 min default

if not TELEGRAM_BOT_TOKEN:
    raise RuntimeError("Missing env TELEGRAM_BOT_TOKEN")
if not DADATA_TOKEN:
    raise RuntimeError("Missing env DADATA_TOKEN")


# -----------------------------
# Simple TTL cache
# -----------------------------
class TTLCache:
    def __init__(self, ttl_sec: int) -> None:
        self.ttl_sec = ttl_sec
        self._store: Dict[str, Tuple[float, Any]] = {}

    def set(self, key: str, value: Any) -> None:
        self._store[key] = (time.time(), value)

    def get(self, key: str) -> Optional[Any]:
        item = self._store.get(key)
        if not item:
            return None
        ts, value = item
        if time.time() - ts > self.ttl_sec:
            self._store.pop(key, None)
            return None
        return value

    def delete(self, key: str) -> None:
        self._store.pop(key, None)


cache = TTLCache(CACHE_TTL_SEC)


# -----------------------------
# DaData API
# -----------------------------
DADATA_SUGGEST_URL = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/suggest/party"
DADATA_FIND_URL = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/findById/party"

HTTP_TIMEOUT_SEC = 20


def _dadata_headers() -> Dict[str, str]:
    # Secret key is NOT required for suggest/findById party, but may be used in profile methods.
    h = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Token {DADATA_TOKEN}",
    }
    return h


def dadata_suggest_party(query: str, count: int = 1) -> List[Dict[str, Any]]:
    payload = {"query": query, "count": count}
    r = requests.post(DADATA_SUGGEST_URL, headers=_dadata_headers(), json=payload, timeout=HTTP_TIMEOUT_SEC)
    r.raise_for_status()
    data = r.json()
    return [s.get("data") for s in data.get("suggestions", []) if s.get("data")]


def dadata_find_party(query: str, count: int = 10, branch_type: Optional[str] = None, kpp: Optional[str] = None) -> List[Dict[str, Any]]:
    payload: Dict[str, Any] = {"query": query, "count": count}
    if branch_type:
        payload["branch_type"] = branch_type
    if kpp:
        payload["kpp"] = kpp
    r = requests.post(DADATA_FIND_URL, headers=_dadata_headers(), json=payload, timeout=HTTP_TIMEOUT_SEC)
    r.raise_for_status()
    data = r.json()
    return [s.get("data") for s in data.get("suggestions", []) if s.get("data")]


# -----------------------------
# Formatting helpers
# -----------------------------
def digits_only(s: str) -> str:
    return re.sub(r"\D+", "", s or "")


def ms_to_date(ms: Any) -> str:
    try:
        if ms is None:
            return "—"
        ms_int = int(ms)
        if ms_int <= 0:
            return "—"
        return time.strftime("%d.%m.%Y", time.localtime(ms_int / 1000))
    except Exception:
        return "—"


def fmt_money_rub(value: Any) -> str:
    if value is None:
        return "—"
    try:
        n = int(value)
    except Exception:
        return "—"
    # 1 234 567 ₽
    s = f"{n:,}".replace(",", " ")
    return f"{s} ₽"


def pick(d: Dict[str, Any], *path: str) -> Any:
    cur: Any = d
    for p in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(p)
    return cur


def party_name(p: Dict[str, Any]) -> str:
    name = pick(p, "name", "short_with_opf") or pick(p, "name", "full_with_opf")
    if name:
        return str(name)
    fio = pick(p, "fio")
    if isinstance(fio, dict):
        parts = [fio.get("surname"), fio.get("name"), fio.get("patronymic")]
        parts = [x for x in parts if x]
        return " ".join(parts) if parts else "—"
    return "—"


def party_address_short(p: Dict[str, Any], limit: int = 90) -> str:
    addr = pick(p, "address", "value") or "—"
    addr = str(addr)
    return addr if len(addr) <= limit else addr[: limit - 1] + "…"


def okved_main_name(p: Dict[str, Any]) -> Optional[str]:
    okved = p.get("okved")
    okveds = p.get("okveds") or []
    if isinstance(okveds, list):
        for item in okveds:
            if not isinstance(item, dict):
                continue
            if item.get("main") is True and item.get("name"):
                return str(item.get("name"))
        for item in okveds:
            if isinstance(item, dict) and item.get("code") == okved and item.get("name"):
                return str(item.get("name"))
    return None


def format_summary(p: Dict[str, Any]) -> str:
    status = pick(p, "state", "status") or "—"
    reg_date = ms_to_date(pick(p, "state", "registration_date"))
    inn = p.get("inn") or "—"
    ogrn = p.get("ogrn") or "—"
    kpp = p.get("kpp") or "—"
    mgmt_name = pick(p, "management", "name") or "—"
    mgmt_post = pick(p, "management", "post") or ""
    mgmt = mgmt_name if not mgmt_post else f"{mgmt_name} ({mgmt_post})"
    okved = p.get("okved") or "—"
    okved_name = okved_main_name(p)
    okved_line = f"<code>{okved}</code>" + (f" — {okved_name}" if okved_name else "")

    invalid = p.get("invalid")
    invalid_line = ""
    if invalid is True:
        invalid_line = "\n⚠️ <b>Есть признаки недостоверности</b> (ЕГРЮЛ)"

    return (
        f"<b>{party_name(p)}</b>\n"
        f"Статус: <b>{status}</b>\n"
        f"ИНН: <code>{inn}</code> | ОГРН: <code>{ogrn}</code> | КПП: <code>{kpp}</code>\n"
        f"Регистрация: <b>{reg_date}</b>\n"
        f"Адрес: {party_address_short(p)}\n"
        f"Руководитель: {mgmt}\n"
        f"ОКВЭД: {okved_line}"
        f"{invalid_line}"
    )


def format_requisites(p: Dict[str, Any]) -> str:
    fields = {
        "ИНН": p.get("inn"),
        "ОГРН": p.get("ogrn"),
        "КПП": p.get("kpp"),
        "ОКПО": p.get("okpo"),
        "ОКАТО": p.get("okato"),
        "ОКТМО": p.get("oktmo"),
        "ОКОГУ": p.get("okogu"),
        "ОКФС": p.get("okfs"),
        "ОКОПФ": pick(p, "opf", "code"),
    }
    lines = [f"<b>Реквизиты</b>", f"{party_name(p)}"]
    for k, v in fields.items():
        if v is None:
            continue
        lines.append(f"{k}: <code>{v}</code>")
    return "\n".join(lines)


def format_contacts(p: Dict[str, Any]) -> str:
    phones = p.get("phones") or []
    emails = p.get("emails") or []

    def norm_list(items: Any, limit: int = 6) -> List[str]:
        out: List[str] = []
        if not isinstance(items, list):
            return out
        for item in items:
            if len(out) >= limit:
                break
            if isinstance(item, str):
                out.append(item)
                continue
            if isinstance(item, dict):
                val = item.get("value") or pick(item, "data", "source") or item.get("phone") or item.get("email")
                if val:
                    out.append(str(val))
        # unique preserve order
        seen = set()
        uniq = []
        for x in out:
            if x in seen:
                continue
            seen.add(x)
            uniq.append(x)
        return uniq

    p_list = norm_list(phones)
    e_list = norm_list(emails)

    lines = [f"<b>Контакты</b>", f"{party_name(p)}"]
    if p_list:
        lines.append("Телефоны:")
        lines.extend([f"• {x}" for x in p_list])
    else:
        lines.append("Телефоны: —")

    if e_list:
        lines.append("Email:")
        lines.extend([f"• {x}" for x in e_list])
    else:
        lines.append("Email: —")

    return "\n".join(lines)


def format_turnover(p: Dict[str, Any]) -> str:
    finance = p.get("finance") or {}
    year = finance.get("year")
    income = finance.get("income")
    revenue = finance.get("revenue")
    expense = finance.get("expense")

    lines = [f"<b>Оборот (бух. отчётность)</b>", f"{party_name(p)}"]
    if year:
        lines.append(f"Год: <b>{year}</b>")
    lines.append(f"Выручка: <b>{fmt_money_rub(revenue)}</b>")
    lines.append(f"Доходы: <b>{fmt_money_rub(income)}</b>")
    lines.append(f"Расходы: <b>{fmt_money_rub(expense)}</b>")
    if all(x is None for x in [year, income, revenue, expense]):
        lines.append("\nНет данных в DaData по бух. отчётности.")
    return "\n".join(lines)


def format_debts(p: Dict[str, Any]) -> str:
    finance = p.get("finance") or {}
    year = finance.get("year")
    debt = finance.get("debt")
    penalty = finance.get("penalty")

    lines = [f"<b>Долги / штрафы (ФНС)</b>", f"{party_name(p)}"]
    if year:
        lines.append(f"Год: <b>{year}</b>")
    lines.append(f"Недоимки по налогам: <b>{fmt_money_rub(debt)}</b>")
    lines.append(f"Налоговые штрафы: <b>{fmt_money_rub(penalty)}</b>")
    if all(x is None for x in [year, debt, penalty]):
        lines.append("\nНет данных в DaData по недоимкам/штрафам.")
    return "\n".join(lines)


def _collect_court_decisions(p: Dict[str, Any]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []

    def add_decision(where: str, inv: Dict[str, Any]) -> None:
        if not isinstance(inv, dict):
            return
        if inv.get("code") != "COURT":
            return
        d = inv.get("decision") or {}
        if not isinstance(d, dict):
            return
        out.append(
            {
                "where": where,
                "court_name": str(d.get("court_name") or "—"),
                "number": str(d.get("number") or "—"),
                "date": str(d.get("date") or "—"),
            }
        )

    # address.invalidity
    addr_inv = pick(p, "address", "invalidity")
    if isinstance(addr_inv, dict):
        add_decision("Адрес", addr_inv)

    # founders[].invalidity
    founders = p.get("founders") or []
    if isinstance(founders, list):
        for f in founders:
            if isinstance(f, dict) and isinstance(f.get("invalidity"), dict):
                add_decision("Учредитель", f["invalidity"])

    # managers[].invalidity
    managers = p.get("managers") or []
    if isinstance(managers, list):
        for m in managers:
            if isinstance(m, dict) and isinstance(m.get("invalidity"), dict):
                add_decision("Руководитель", m["invalidity"])

    # unique by tuple
    seen = set()
    uniq: List[Dict[str, str]] = []
    for x in out:
        key = (x["where"], x["court_name"], x["number"], x["date"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(x)
    return uniq


def format_courts(p: Dict[str, Any]) -> str:
    status = pick(p, "state", "status") or "—"
    code = pick(p, "state", "code")
    liq_date = ms_to_date(pick(p, "state", "liquidation_date"))

    lines = [f"<b>Суды / юр. признаки</b>", f"{party_name(p)}"]
    lines.append(f"Статус ЕГРЮЛ: <b>{status}</b>")
    if code:
        lines.append(f"Детальный статус: <code>{code}</code>")
    if liq_date != "—":
        lines.append(f"Дата ликвидации/стадии: <b>{liq_date}</b>")

    decisions = _collect_court_decisions(p)
    if decisions:
        lines.append("\nРешения суда о недостоверности сведений:")
        for d in decisions[:8]:
            lines.append(
                f"• {d['where']}: {d['court_name']}, № {d['number']}, дата {d['date']}"
            )
        if len(decisions) > 8:
            lines.append(f"… ещё {len(decisions) - 8}")
    else:
        lines.append("\nРешений суда о недостоверности сведений в данных DaData не найдено.")

    lines.append("\nЕсли нужен полный список дел (арбитраж/общая юрисдикция) — подключается отдельный источник (например, Контур.Фокус/СПАРК).")
    return "\n".join(lines)


def format_founders(p: Dict[str, Any]) -> str:
    founders = p.get("founders") or []
    lines = [f"<b>Учредители</b>", f"{party_name(p)}"]
    if not isinstance(founders, list) or not founders:
        lines.append("Нет данных в DaData.")
        return "\n".join(lines)

    def fmt_share(f: Dict[str, Any]) -> str:
        share = f.get("share") or {}
        if not isinstance(share, dict):
            return ""
        t = share.get("type")
        if t == "PERCENT":
            v = share.get("value")
            if v is None:
                return ""
            return f"{v}%"
        if t == "DECIMAL":
            v = share.get("value")
            if v is None:
                return ""
            return str(v)
        if t == "FRACTION":
            n = share.get("numerator")
            d = share.get("denominator")
            if n and d:
                return f"{n}/{d}"
        return ""

    for f in founders[:10]:
        if not isinstance(f, dict):
            continue
        title = f.get("name") or f.get("fio") or "—"
        inn = f.get("inn") or ""
        share = fmt_share(f)
        share_txt = f", доля {share}" if share else ""
        inn_txt = f" (ИНН {inn})" if inn else ""
        lines.append(f"• {title}{inn_txt}{share_txt}")
    if len(founders) > 10:
        lines.append(f"… ещё {len(founders) - 10}")
    return "\n".join(lines)


# -----------------------------
# Telegram bot
# -----------------------------
bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN, parse_mode="HTML")


def kb_summary(key: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.row(
        InlineKeyboardButton("📄 Реквизиты", callback_data=f"REQ|{key}"),
        InlineKeyboardButton("📞 Контакты", callback_data=f"CONTACTS|{key}"),
    )
    kb.row(
        InlineKeyboardButton("💰 Оборот", callback_data=f"TURNOVER|{key}"),
        InlineKeyboardButton("🧾 Долги", callback_data=f"DEBTS|{key}"),
    )
    kb.row(
        InlineKeyboardButton("⚖️ Суды", callback_data=f"COURTS|{key}"),
        InlineKeyboardButton("👥 Учредители", callback_data=f"FOUNDERS|{key}"),
    )
    kb.row(
        InlineKeyboardButton("🔁 Новый поиск", callback_data="NEW|0"),
    )
    return kb


def kb_detail(key: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardMarkup()
    kb.row(
        InlineKeyboardButton("⬅️ Назад", callback_data=f"BACK|{key}"),
        InlineKeyboardButton("🔁 Новый поиск", callback_data="NEW|0"),
    )
    return kb


def _cache_key(chat_id: int, key: str) -> str:
    return f"party:{chat_id}:{key}"


def _extract_inn_kpp(text: str) -> Tuple[Optional[str], Optional[str]]:
    # Patterns: 7707083893/540602001 or "7707083893 540602001"
    m = re.search(r"(\d{10,12})\s*/\s*(\d{9})", text)
    if m:
        return m.group(1), m.group(2)
    m = re.search(r"(\d{10,12})\s+(\d{9})", text)
    if m:
        return m.group(1), m.group(2)
    return None, None


def _pick_best_party_from_suggest(items: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not items:
        return None
    # best = first (DaData already ranks)
    return items[0]


def _get_party_full(query_text: str) -> Optional[Dict[str, Any]]:
    query_text = (query_text or "").strip()
    if not query_text:
        return None

    inn, kpp = _extract_inn_kpp(query_text)
    suggest_query = inn if inn else query_text

    suggestions = dadata_suggest_party(suggest_query, count=1)
    best = _pick_best_party_from_suggest(suggestions)
    if not best:
        return None

    inn_best = best.get("inn")
    ogrn_best = best.get("ogrn")
    key = inn_best or ogrn_best or suggest_query

    # Get extended fields via findById (DaData docs: this is where finance/founders/phones/emails appear)
    try:
        if inn and kpp:
            find_query = f"{inn}/{kpp}"
            found = dadata_find_party(find_query, count=5)
        else:
            found = dadata_find_party(str(key), count=5, branch_type="MAIN")
    except Exception:
        # fallback: use suggest data if findById fails
        return best

    if not found:
        return best
    return found[0]


def _safe_edit_or_send(chat_id: int, message_id: int, text: str, reply_markup: Optional[InlineKeyboardMarkup]) -> None:
    try:
        bot.edit_message_text(text=text, chat_id=chat_id, message_id=message_id, reply_markup=reply_markup)
    except Exception:
        bot.send_message(chat_id, text, reply_markup=reply_markup)


@bot.message_handler(commands=["start"])
def on_start(m):
    bot.send_message(
        m.chat.id,
        "Пришлите ИНН / ОГРН / название компании — верну краткую карточку + кнопки (суды, оборот, долги).",
    )


@bot.message_handler(content_types=["text"])
def on_text(m):
    q = (m.text or "").strip()
    if not q:
        return

    try:
        party = _get_party_full(q)
    except requests.HTTPError as e:
        bot.send_message(m.chat.id, f"DaData вернул ошибку: {e}")
        return
    except Exception:
        bot.send_message(m.chat.id, "Ошибка запроса к DaData. Проверь токен/лимиты.")
        return

    if not party:
        bot.send_message(m.chat.id, "Ничего не нашёл. Проверь ИНН/ОГРН или уточни название.")
        return

    key = str(party.get("inn") or party.get("ogrn") or digits_only(q) or q)[:32]
    summary = format_summary(party)
    cache.set(_cache_key(m.chat.id, key), {"party": party, "summary": summary})

    bot.send_message(m.chat.id, summary, reply_markup=kb_summary(key))


@bot.callback_query_handler(func=lambda c: True)
def on_cb(c):
    data = c.data or ""
    bot.answer_callback_query(c.id)

    if data.startswith("NEW|"):
        bot.send_message(c.message.chat.id, "Ок. Пришли новый ИНН / ОГРН / название.")
        return

    if "|" not in data:
        return

    action, key = data.split("|", 1)
    payload = cache.get(_cache_key(c.message.chat.id, key))
    if not payload:
        bot.send_message(c.message.chat.id, "Контекст устарел. Пришли ИНН заново.")
        return

    party = payload["party"]
    summary = payload["summary"]

    if action == "BACK":
        _safe_edit_or_send(c.message.chat.id, c.message.message_id, summary, kb_summary(key))
        return

    if action == "REQ":
        text = format_requisites(party)
    elif action == "CONTACTS":
        text = format_contacts(party)
    elif action == "TURNOVER":
        text = format_turnover(party)
    elif action == "DEBTS":
        text = format_debts(party)
    elif action == "COURTS":
        text = format_courts(party)
    elif action == "FOUNDERS":
        text = format_founders(party)
    else:
        text = "Неизвестная команда."

    _safe_edit_or_send(c.message.chat.id, c.message.message_id, text, kb_detail(key))


# -----------------------------
# FastAPI app (webhook)
# -----------------------------
app = FastAPI()


@app.get("/healthx")
def health():
    return {"status": "ok"}


@app.post(f"/webhook/{WEBHOOK_PATH_SECRET}")
async def telegram_webhook(req: Request):
    # Optional validation using Telegram secret_token header (recommended by Telegram)
    if WEBHOOK_SECRET_TOKEN:
        header = req.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if header != WEBHOOK_SECRET_TOKEN:
            raise HTTPException(status_code=401, detail="Invalid Telegram secret token")

    try:
        payload = await req.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    try:
        update = telebot.types.Update.de_json(payload)
        bot.process_new_updates([update])
    except Exception:
        # Don't leak details; Telegram expects 200 for most cases to avoid retries storm
        return Response(status_code=200, content=json.dumps({"ok": False}))

    return {"ok": True}
