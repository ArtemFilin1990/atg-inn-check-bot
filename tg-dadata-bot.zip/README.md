# Telegram бот: DaData (Max) + Amvera (webhook)

Функции:
- Пользователь отправляет **ИНН / ОГРН / название**
- Бот отвечает **краткой карточкой** и показывает кнопки:
  - 📄 Реквизиты
  - 📞 Контакты
  - 💰 Оборот (выручка/доходы/расходы)
  - 🧾 Долги (недоимки/штрафы)
  - ⚖️ Суды / юр. признаки (в рамках DaData: статус, + решения суда о недостоверности сведений, если есть)
  - 👥 Учредители

## 1) Переменные окружения (Amvera → «Переменные и секреты»)

Обязательные:
- `TELEGRAM_BOT_TOKEN` — токен бота от BotFather
- `DADATA_TOKEN` — API-ключ DaData (тариф Max)
- `TELEGRAM_WEBHOOK_PATH_SECRET` — секретный хвост URL (любая строка)

Рекомендуемые:
- `TELEGRAM_WEBHOOK_SECRET_TOKEN` — секрет для заголовка `X-Telegram-Bot-Api-Secret-Token`
- `PYTHONUNBUFFERED=1` — чтобы логи сразу появлялись в Amvera

Опционально:
- `CACHE_TTL_SEC=900` — TTL кэша (сек), по умолчанию 900

## 2) Развертывание на Amvera

Файлы уже готовы:
- `requirements.txt`
- `amvera.yml` (Python Pip + Uvicorn)

После push в репозиторий Amvera проект соберётся и запустится.

Проверка живости:
- `GET /healthx` → `{"status":"ok"}`

## 3) Установка webhook в Telegram

Telegram рекомендует:
- секретный путь в URL
- (опционально) `secret_token` — Telegram будет отправлять его в заголовке `X-Telegram-Bot-Api-Secret-Token`

Документация: https://core.telegram.org/bots/api#setwebhook

### Команда (curl)

Замените:
- `<BOT_TOKEN>` — токен бота
- `<DOMAIN>` — домен/URL вашего приложения (например `https://api.ewerest.ru`)
- `<PATH_SECRET>` — значение `TELEGRAM_WEBHOOK_PATH_SECRET`
- `<SECRET_TOKEN>` — значение `TELEGRAM_WEBHOOK_SECRET_TOKEN` (если используете)

**Вариант с secret_token (рекомендуется):**
```bash
curl -X POST "https://api.telegram.org/bot<BOT_TOKEN>/setWebhook" \
  -d "url=https://<DOMAIN>/webhook/<PATH_SECRET>" \
  -d "secret_token=<SECRET_TOKEN>" \
  -d 'allowed_updates=["message","callback_query"]' \
  -d "drop_pending_updates=true"
```

**Вариант без secret_token (минимальный):**
```bash
curl -F "url=https://<DOMAIN>/webhook/<PATH_SECRET>" \
  "https://api.telegram.org/bot<BOT_TOKEN>/setWebhook"
```

Проверить webhook:
```bash
curl "https://api.telegram.org/bot<BOT_TOKEN>/getWebhookInfo"
```

## 4) Локальный запуск (для теста)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN="..."
export DADATA_TOKEN="..."
export TELEGRAM_WEBHOOK_PATH_SECRET="secret-path"
uvicorn --host 0.0.0.0 --port 8080 app:app
```

Дальше ставите webhook на публичный URL (ngrok/домен).
